const sineTween = function ({ start, end, duration = 1 }) {
   this.time = 0;
   this.start = start;
   this.end = end;
   this.duration = duration;
};

sineTween.prototype.update = function (delta) {
   this.time = Math.min(this.time + delta, this.duration);
   this.percTime = this.time / this.duration;
   const PIx2 = -1 + this.percTime * 2; //range -1 to 1
   const modPIx2 = Math.pow(Math.abs(PIx2), 0.9) * (PIx2 < 0 ? -1 : 1);
   this.percDistance = (Math.sin(modPIx2 * 0.5 * Math.PI) + 1) * 0.5; //convert to 0 to 1;
   const x = this.start.x + (this.end.x - this.start.x) * this.percDistance;
   const y = this.start.y + (this.end.y - this.start.y) * this.percDistance;

   return { x, y, complete: this.percTime === 1 };
};

export { sineTween };
