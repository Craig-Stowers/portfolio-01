import "./App.css";
import Navbar from "./components/Navbar";
import { Routes, Route } from "react-router-dom";
import { useEffect, useLayoutEffect, useState, useRef } from "react";

import "./fonts/OPTIStaines-Extended.otf";

import ProjectsPage from "./components/pages/ProjectsPage";

import background from "./images/grid-tile.png";

import CodeBlock from "./components/CodeBlock";

import Home from "./components/pages/Home";

import {
   BrowserView,
   MobileView,
   isBrowser,
   isMobile,
} from "react-device-detect";

// let codeSnippets = require.context('./components/code', true);
// let code = codeSnippets(`./${"testcode.txt"}`);

const code = require(`./components/code/${"testcode"}.txt`);

function App() {
   const [showNav, setShowNav] = useState(true);
   const [scrollY, setScrollY] = useState(window.scrollY);
   const parallaxRef1 = useRef(null);
   const parallaxRef2 = useRef(null);

   const [codeString, setCodeString] = useState("");

   useEffect(() => {
      fetch(code)
         .then((t) => t.text())
         .then((text) => {
            setCodeString(text);
         });
   }, []);

   // useLayoutEffect(() => {
   //    let oldY = window.scrollY;

   //    let showNavTimer = null;

   //    const handleScroll = (e) => {
   //       if (window.scrollY > oldY && window.scrollY > 40) {
   //          setShowNav(false);
   //          clearTimeout(showNavTimer);
   //          showNavTimer = null;
   //       } else {
   //          if (!showNavTimer) {
   //             showNavTimer = setTimeout(() => {
   //                setShowNav(true);
   //             }, 50);
   //          }
   //       }

   //       // console.log(e);
   //       oldY = window.scrollY;
   //       parallaxRef1.current.style.top = -oldY * 0.3 + "px";
   //       parallaxRef2.current.style.top = -oldY * 0.14 + "px";
   //       setScrollY(oldY);
   //    };

   //    document.addEventListener("scroll", handleScroll);

   //    return () => document.removeEventListener("scroll", handleScroll);
   // }, []);

   return (
      <div className="App">
         <CodeBlock codeString={codeString} />
         {/* <div className="debug">
            showNav: {showNav ? "true" : "false"} | scrollY: {scrollY}
         </div>
         <div className="parallax1" ref={parallaxRef1}></div>
         <div
            className="parallax2"
            ref={parallaxRef2}
            style={{
               backgroundImage: `url(${background})`,
               backgroundPosition: "center",
               backgroundSize: "50px",
            }}
         ></div>

         <header className={`App-header${!showNav ? " hideNav" : ""}`}>
            <Navbar
               items={[
                  "about",
                  "work",
                  "projects",
                  "snippets",
                  "blog",
                  "contact",
               ]}
            />
         </header> */}

         {isMobile && (
            <h3 style={{ color: "white" }}>
               Mobile version in development. Please open on a desktop browser.
            </h3>
         )}

         {!isMobile && (
            <div id="content">
               <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="about" element={<About />} />
                  <Route path="work" element={<Work />} />
                  <Route path="projects" element={<ProjectsPage />} />
                  <Route path="snippets" element={<Snippets />} />
                  <Route path="blog" element={<Blog />} />
                  <Route path="contact" element={<Contact />} />
               </Routes>
            </div>
         )}

         {/* <div className="water"></div> */}
      </div>
   );
}

const About = () => {
   return (
      <div className="about">
         {/* <div className="introduction">
            <h3>Hi, my name is</h3>
            <h2>
               <span className="name">test  test test test test test Hi, I'm <span>C</span><span>r</span><span>a</span><span>i</span><span>g</span><span>.</span></span><br/>
               <span className="slogan">I build interactive web apps.</span>
            </h2>
            <div className="titleMessage">
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
               I’m a software engineer specializing in building (and
               occasionally designing) exceptional digital experiences.
               Currently, I’m focused on building accessible, human-centered
               products for the NSW government.
            </div>
         </div> */}
      </div>
   );
};

const Work = () => {
   return (
      <div className="about">
         <h3>Work</h3>
         <p>
            Suspendisse potenti. Donec nec magna sem. Sed sapien metus, dictum a
            faucibus sed, gravida in ligula. Aenean vitae sapien justo. Maecenas
            nec laoreet turpis. Donec porttitor iaculis urna non elementum. Cras
            ullamcorper ornare arcu sed posuere. Maecenas imperdiet sapien eu
            justo cursus, tempus ultricies arcu luctus.
         </p>
         <p>
            Maecenas et mi est. Duis cursus arcu vitae nulla pharetra, at
            maximus mauris vulputate. Praesent sed gravida justo, vel fermentum
            enim. Duis at nibh mollis, condimentum dolor nec, ullamcorper nisl.
            In ante ex, pretium auctor varius non, mattis eget justo. Aenean
            egestas, elit vitae tincidunt maximus, ante lorem tempor nisi, ut
            vehicula sem magna at dui. Integer tristique nulla vel nunc aliquet
            sollicitudin.
         </p>
         <p>
            Integer in odio nec sem fermentum euismod vel sed quam. Nulla at
            erat egestas, consequat mi non, auctor magna. Duis est mi, aliquam
            fringilla tellus vel, iaculis varius tortor. Sed porttitor nec quam
            quis euismod. Duis at aliquam dui, id dapibus erat. Cras molestie eu
            felis vitae ultrices. Suspendisse potenti.
         </p>
         <p>
            Suspendisse potenti. Donec nec magna sem. Sed sapien metus, dictum a
            faucibus sed, gravida in ligula. Aenean vitae sapien justo. Maecenas
            nec laoreet turpis. Donec porttitor iaculis urna non elementum. Cras
            ullamcorper ornare arcu sed posuere. Maecenas imperdiet sapien eu
            justo cursus, tempus ultricies arcu luctus.
         </p>
         <p>
            Maecenas et mi est. Duis cursus arcu vitae nulla pharetra, at
            maximus mauris vulputate. Praesent sed gravida justo, vel fermentum
            enim. Duis at nibh mollis, condimentum dolor nec, ullamcorper nisl.
            In ante ex, pretium auctor varius non, mattis eget justo. Aenean
            egestas, elit vitae tincidunt maximus, ante lorem tempor nisi, ut
            vehicula sem magna at dui. Integer tristique nulla vel nunc aliquet
            sollicitudin.
         </p>
         <p>
            Integer in odio nec sem fermentum euismod vel sed quam. Nulla at
            erat egestas, consequat mi non, auctor magna. Duis est mi, aliquam
            fringilla tellus vel, iaculis varius tortor. Sed porttitor nec quam
            quis euismod. Duis at aliquam dui, id dapibus erat. Cras molestie eu
            felis vitae ultrices. Suspendisse potenti.
         </p>
      </div>
   );
};

const Snippets = () => {
   return <div>Snippets</div>;
};

const Blog = () => {
   return <div>Blog</div>;
};

const Contact = () => {
   return <div>Contact</div>;
};
export default App;
