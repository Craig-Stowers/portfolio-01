import { useEffect, useRef, useState } from "react";
import ScaredText from "../ScaredText";
import classes from "./HomeStyles.module.css";
import SpanChars from "../shared/SpanChars";

import { funText, getMinimumCharsFromStrings } from "../util/funtext";

const Home = () => {
   const [selectedP, setSelectedP] = useState(null);
   const spanCollectionRef = useRef([]);
   const spanCollectionRefFlat = useRef([]);
   const letterPoolSpans = useRef([]);
   const textContainerRefs = useRef([]);
   const [charPoolString, setCharPoolString] = useState("");
   const letterSwitcher = useRef();
   const lastTime = useRef(0);
   const requestRef = useRef();
   const playAreaRef = useRef();

   const animate = (time) => {
      requestRef.current = requestAnimationFrame(animate);
      const delta = time - (lastTime.current ? lastTime.current : 0);
      lastTime.current = time;
      letterSwitcher.current.update(delta);
   };

   const handleResize = () => {
      if (letterSwitcher.current) {
         letterSwitcher.current.resize();
      }
   };

   useEffect(() => {
      const spanGroupsToStrings = spanCollectionRefFlat.current.map((group) => {
         return group
            .map((obj) => {
               return obj.innerText === " " ? "" : obj.innerText;
            })
            .join("");
      });
      const minChars = getMinimumCharsFromStrings(spanGroupsToStrings);

      console.log("minChars", minChars);
      setCharPoolString(minChars);
      letterSwitcher.current = new funText(playAreaRef.current);
      letterSwitcher.current.setTrackers([...letterPoolSpans.current]);
      requestRef.current = requestAnimationFrame(animate);
      window.addEventListener("resize", handleResize);
      return () => {
         letterSwitcher.current.kill();
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(requestRef.current);
      };
   }, []);

   useEffect(() => {
      if (spanCollectionRef.current[selectedP] == null) return;

      const { left, top, width, height } =
         textContainerRefs.current[selectedP].getBoundingClientRect();
      const centrePoint = { x: left + width * 0.5, y: top + height * 0.5 };

      letterSwitcher.current.setTargets(
         [...spanCollectionRefFlat.current[selectedP]],
         centrePoint
      );
   }, [selectedP, spanCollectionRef]);

   const handleSpanRefs = (refs, paragraphIndex, group) => {
      // if (group) {
      //    const old = [...spanCollectionRef.current[paragraphIndex]] || [];
      //    spanCollectionRef.current[paragraphIndex] = [...old, ...refs];
      // } else {
      if (!spanCollectionRef.current[paragraphIndex])
         spanCollectionRef.current[paragraphIndex] = [];

      spanCollectionRef.current[paragraphIndex][group] = [...refs];

      spanCollectionRefFlat.current[paragraphIndex] =
         spanCollectionRef.current[paragraphIndex].flat();
      // }

      if (selectedP === null) {
         setSelectedP(0);
      }
   };

   const handleCharPoolRefs = (refs) => {
      if (letterSwitcher.current) {
         letterSwitcher.current.setTrackers([...refs]);
      }
   };

   const messsages = [
      <>
         <SpanChars onSpanRefs={(refs) => handleSpanRefs(refs, 0, 0)}>
            XXXHi My name is craig
         </SpanChars>
         <h1>
            <SpanChars onSpanRefs={(refs) => handleSpanRefs(refs, 0, 1)}>
               ZZZSome other stuff
            </SpanChars>
         </h1>
      </>,
      <SpanChars onSpanRefs={(refs) => handleSpanRefs(refs, 1, 0)}>
         I like to make creative code projects with lots of interactions. I love
         making games and playing around with mathetmatics
      </SpanChars>,
   ];

   // const messages = [

   // ]

   return (
      <div className={classes.Home}>
         <div
            ref={playAreaRef}
            className={classes.playArea}
            style={{
               backgroundColor: "#99333350",

               height: "100vh",
               position: "relative",
            }}
         >
            {[1, 2, 3, 4, 5].map((e, i) => {
               return (
                  <button
                     key={i}
                     onClick={() => {
                        setSelectedP(i);
                     }}
                  >
                     paragraph {i}
                  </button>
               );
            })}

            {messsages.map((message, i) => {
               return (
                  <div
                     ref={(ref) => textContainerRefs.current.push(ref)}
                     key={"message" + i}
                     className={classes.hoverText}
                     style={{
                        color: selectedP === i ? "green" : "black",
                        position: "absolute",
                        opacity: 0,
                     }}
                  >
                     {message}
                     {/* <SpanChars onSpanRefs={(ref) => handleSpanRefs(ref, i)}>
                        {message}
                     </SpanChars> */}
                  </div>
               );
            })}

            {/* <div
               className={classes.hoverText}
               style={{
                  color: selectedP === 2 ? "green" : "black",
                  position: "absolute",
                  opacity: 0,
               }}
            >
               <SpanChars onSpanRefs={(refs) => handleSpanRefs(refs, 3)}>
                  This is another test sentence saying something about my work i
                  did making e-learning modules.
               </SpanChars>
            </div>

            <div
               className={classes.hoverText}
               style={{
                  color: selectedP === 2 ? "green" : "black",
                  position: "absolute",
                  opacity: 0,
               }}
            >
               <SpanChars onSpanRefs={(refs) => handleSpanRefs(refs, 4)}>
                  I'm really sick of coming up with ideas for sentences. Blah
                  blah blah, fuck Russia.
               </SpanChars>
            </div> */}

            <div
               className={classes.trackerText}
               style={{ wordBreak: "break-all", color: "red" }}
            >
               <SpanChars onSpanRefs={handleCharPoolRefs} absolute>
                  {charPoolString}
               </SpanChars>
            </div>
         </div>

         {/* <div className="funtext">
            <p>
               <ScaredText
                  text={
                     "I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. I love creative coding. "
                  }
               />
            </p>
         </div> */}
      </div>
   );
};

export default Home;
