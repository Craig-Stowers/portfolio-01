import { sineTween } from "../../utility/Tweens";

const padding = 50;

const getAngle = (dx, dy) => Math.atan2(dx, dy) * (180 / Math.PI);
const getXY = ({ x, y }) => ({ x, y });

const getMinimumCharsFromStrings = (strings) => {
   let minChars = [];
   for (var i = 0; i < strings.length; i++) {
      const string = strings[i];
      let charBank = [...minChars];
      let charsRequired = [];
      for (var j = 0; j < string.length; j++) {
         const char = string[j];
         const foundCharIndex = charBank.findIndex((item) => item === char);
         if (foundCharIndex !== -1) charBank.splice(foundCharIndex, 1);
         charsRequired.push(char);
      }
      minChars = [...charBank, ...charsRequired];
   }
   return minChars.join("");
};

const funText = function (playArea) {
   this.targets = [];
   this.trackers = [];
   this.playArea = getPlayAreaParams(playArea);
   this.explodeGuides = [];
   this.unlinked = [];
};

const getPlayAreaParams = (element) => {
   const rect = element.getBoundingClientRect();
   return {
      element,
      x: rect.left,
      y: rect.top,
      width: rect.width,
      height: rect.height,
   };
};

funText.prototype.setTrackers = function (spansArr) {
   this.trackers = spansArr.map((e, i) => {
      const rect = e.getBoundingClientRect();
      const randomPos = this.getRandomXY();

      return {
         element: e,
         char: e.innerText,
         x: 0,
         y: 0,
         baseX: 0,
         baseY: 0,
         link: null,
         vx: 0,
         vy: 0,
         opacity: 0,
         lockstep: true,
      };
   });
};

funText.prototype.resize = function () {
   this.playArea = getPlayAreaParams(this.playArea.element);

   //get new guide text positions
   this.targets.forEach((e) => {
      const rect = e.element.getBoundingClientRect();
      e.x = rect.left - this.playArea.x;
      e.y = rect.top - this.playArea.y;
   });
   this.trackers.forEach((e) => {
      //update target position if linked
      // if (e.link != null) e.baseX = this.targets[e.link].x;
      // if (e.link != null) e.baseY = this.targets[e.link].y;

      // //instantly shift other objects. i.e entering/exiting letters
      // if (e.link == null) e.x = e.xp * this.playArea.width;
      // if (e.link == null) e.y = e.yp * this.playArea.height;

      if (e.link != null) {
         e.baseX = this.targets[e.link].x;
         e.baseY = this.targets[e.link].y;
      }

      e.lockstep = false;

      //   e.baseX = this.targets[e.link].x;
      //   e.baseY = this.targets[e.link].y;

      if (e.tween) {
         const movedTarget = this.targets[e.link];
         e.tween.end.x = movedTarget.x;
         e.tween.end.y = movedTarget.y;
         //mod tween start position to by "reverse engineering" from new end point
         e.tween.start.x =
            e.tween.end.x +
            (e.x - e.tween.end.x) * (1 / (1 - e.tween.percDistance));
         e.tween.start.y =
            e.tween.end.y +
            (e.y - e.tween.end.y) * (1 / (1 - e.tween.percDistance));
      }
   });
};

const createGuidePoint = (point, parent, color = "#FF0000", text = null) => {
   const span = document.createElement("span");

   if (text) span.appendChild(document.createTextNode(text));
   span.style.position = "absolute";
   span.style.padding = "0px";
   span.style.margin = "0px";
   // span.style.backgroundColor = color;
   span.style.width = "10px";
   span.style.height = "10px";
   span.style.borderRadius = "5px";
   span.style.transform = "translate(-50%, -50%)";
   span.style.left = `${point.x}px`;
   span.style.top = `${point.y}px`;
   parent.appendChild(span);
   const guide = {
      element: span,
      x: point.x,
      y: point.y,
   };
   return guide;
};

funText.prototype.addGuides = function (count) {
   if (this.midGuide) this.midGuide.element.remove();
   this.midGuide = createGuidePoint(
      this.midPoint,
      this.playArea.element,
      "#00FF00"
   );
   for (let i = 0; i < this.explodeGuides.length; i++) {
      this.explodeGuides[i].element.remove();
   }
   this.explodeGuides = [];
   for (var i = 0; i < count; i++) {
      const angle = (360 / count) * i;
      const x = this.midPoint.x + Math.sin(angle * (Math.PI / 180)) * 500;
      const y = this.midPoint.y + Math.cos(angle * (Math.PI / 180)) * 500;
      const halfX = this.midPoint.x + Math.sin(angle * (Math.PI / 180)) * 250;
      const halfY = this.midPoint.y + Math.cos(angle * (Math.PI / 180)) * 250;

      const guide = createGuidePoint(
         { x, y },
         this.playArea.element,
         "#00FF00",
         i.toString()
      );

      guide.halfX = halfX;
      guide.halfY = halfY;

      this.explodeGuides.push(guide);
   }
};

funText.prototype.findTrackerMatch = function (targetChar) {
   const index = this.trackers.findIndex((e) => {
      return e.char === targetChar && e.link == null;
   });
   return index;
};

funText.prototype.setTargets = function (spansArr, centrePoint) {
   this.midPoint = centrePoint; //this.getMidPoint();
   this.targets = spansArr.map((e, i) => {
      const rect = e.getBoundingClientRect();
      return {
         element: e,
         char: e.innerText,
         x: rect.left - this.playArea.x,
         y: rect.top - this.playArea.y,
      };
   });
   const prevLinked = this.trackers.filter((tracker) => tracker.link != null);
   //reset link so can begin search cycle
   this.trackers.forEach((tracker) => {
      tracker.link = null;
   });
   const matched = [];
   this.targets.forEach((target, index) => {
      const trackerIndex = this.findTrackerMatch(target.char);
      if (trackerIndex !== -1) {
         const matchedTracker = this.trackers[trackerIndex];
         console.log("get font", target.element.style.fontSize);

         var style = window
            .getComputedStyle(target.element, null)
            .getPropertyValue("font-size");
         var fontSize = parseFloat(style);
         matchedTracker.element.style.fontSize = fontSize + "px";
         matchedTracker.link = index;
         matched.push(matchedTracker);
      }
   });
   const newLinks = matched.filter((tracker) => !prevLinked.includes(tracker));
   const oldLinks = matched.filter((tracker) => prevLinked.includes(tracker));
   this.unlinked = prevLinked.filter((tracker) => !matched.includes(tracker));

   newLinks.forEach((tracker) => {
      const target = this.targets[tracker.link];
      tracker.lockstep = false;
      tracker.x = target.x;
      tracker.y = target.y + 100;
      tracker.baseX = target.x;
      tracker.baseY = target.y;
      tracker.opacity = 0;
      //fan timing based dx from mid
      tracker.enterTimer = -220 - Math.abs(target.x - this.midPoint.x) * 0.7;
   });

   oldLinks.forEach((tracker) => {
      const target = this.targets[tracker.link];
      tracker.moveTimer = -100; //- Math.abs(target.x - this.midPoint.x) * 0.7;
      const start = getXY(tracker);
      const end = getXY(target);
      const tweenParams = {
         start: {
            ...start,
            xp: start.x / this.playArea.width,
            yp: start.y / this.playArea.height,
         },
         end: {
            ...end,
            xp: end.x / this.playArea.width,
            yp: end.y / this.playArea.height,
         },
         duration: 2000 + getDistance(tracker, target) * 2,
      };
      tracker.tween = new sineTween(tweenParams);
   });

   this.unlinked.forEach((tracker, i) => {
      console.log("unlink");
      tracker.link = null;
      tracker.vy = -0.2;
      tracker.exitTimer = -Math.abs(tracker.x - this.midPoint.x) * 0.7;
   });
};

const getDistance = (point1, point2) => {
   const dx = point2.x - point1.x;
   const dy = point2.y - point1.y;
   return Math.sqrt(dx * dx + dy * dy);
};

funText.prototype.matchWithTrajectoryOption = function (trackers) {
   this.addGuides(trackers.length);
   //map array to retain original index after array is spliced
   const availablePositions = this.explodeGuides.map((e, i) => {
      return {
         index: i,
         value: e,
      };
   });
   const availableTrackers = trackers.map((e, i) => {
      return {
         index: i,
         value: e,
      };
   });
   const findCleanMatch = (positions, trackers) => {
      for (let i = 0; i < positions.length; i++) {
         const trackerDistances = trackers.map((tracker) => {
            return getDistance(tracker.value, positions[i].value);
         });
         const minTrackerIndex = trackerDistances.indexOf(
            Math.min(...trackerDistances)
         );
         const positionDistances = positions.map((testPosition) => {
            return getDistance(
               trackers[minTrackerIndex].value,
               testPosition.value
            );
         });
         const minPositionIndex = positionDistances.indexOf(
            Math.min(...positionDistances)
         );
         if (minPositionIndex === i)
            return { trackerIndex: minTrackerIndex, positionIndex: i };
      }
      return null;
   };

   const matches = [];
   while (availablePositions.length > 0) {
      const { trackerIndex, positionIndex } = findCleanMatch(
         availablePositions,
         availableTrackers
      );
      matches.push({
         trackerIndex: availableTrackers[trackerIndex].index,
         positionIndex: availablePositions[positionIndex].index,
      });
      availablePositions.splice(positionIndex, 1);
      availableTrackers.splice(trackerIndex, 1);
   }
   return matches;
};

funText.prototype.getMidPoint = function () {
   const linkedLetters = this.targets.filter((e) => e);

   const left = Math.min(...linkedLetters.map((e) => e.x));
   const right = Math.max(...linkedLetters.map((e) => e.x));
   const top = Math.min(...linkedLetters.map((e) => e.y));
   const bottom = Math.max(...linkedLetters.map((e) => e.y));
   return { x: (left + right) * 0.5, y: (top + bottom) * 0.5 };
};

funText.prototype.fanFromPoint = function (letter, point) {
   const newX = (letter.x - point.x) * 0.005;
   const newY = (letter.y - point.y) * 0.005;

   return { x: newX, y: newY };
};

funText.prototype.getRandomXY = function () {
   return {
      x: padding + Math.random() * (this.playArea.width - padding * 2),
      y: padding + Math.random() * (this.playArea.height - padding * 2),
   };
};

funText.prototype.start = function () {};

funText.prototype.kill = function () {
   // this.trackedSpans = null;
   // this.trackingSpans = null;
};

funText.prototype.letterForces = function () {
   // if (!this.looseTrackers) return;
   //this.looseTrackers.forEach((letterA, i) => {
   //  letterA.opacity = Math.max(letterA.opacity - 0.001, 0);
   // const [dx, dy] = [
   //    letterA.x - this.midPoint.x,
   //    letterA.y - this.midPoint.y,
   // ];
   // const d = Math.sqrt(dx * dx + dy * dy) * 0.01;
   // const invsd = d * d * 0.001;
   // const pullX = -dx * invsd * 0.1;
   // const pullY = -dy * invsd * 0.1;
   // letterA.vx += pullX;
   // letterA.vy += pullY;
   // if (this.targets.length) {
   //    this.targets.forEach((targetLetter, targetIndex) => {
   //       const [dx, dy] = [
   //          letterA.x - targetLetter.x,
   //          letterA.y - targetLetter.y,
   //       ];
   //       const d = Math.sqrt(dx * dx + dy * dy) * 0.1;
   //       const invsd = (1 / (d * d)) * 0.001;
   //       const pullX = -dx * invsd * 0.1;
   //       const pullY = -dy * invsd * 0.1;
   //       letterA.vx += pullX;
   //       letterA.vy += pullY;
   //    });
   // }
   // this.looseTrackers.forEach((letterB, j) => {
   // if (j !== i) {
   //    const [dx, dy] = [letterA.x - letterB.x, letterA.y - letterB.y];
   //    const d = Math.sqrt(dx * dx + dy * dy) * 0.1;
   //    const invsd = 1 / (d * d * d);
   //    const pushX = -dx * invsd * 0.1;
   //    const pushY = -dy * invsd * 0.1;
   //    letterB.vx += pushX;
   //    letterB.vy += pushY;
   // }
   //});
   // });
};

funText.prototype.flyaway = function (e) {
   if (e.opacity > 0) {
      e.vy *= 1.04;
      const opacity = 2 - Math.abs(e.y - this.midPoint.y) / 100;
      e.opacity = Math.max(Math.min(opacity, 1), 0);
      e.baseX += e.vx;
      e.baseY += e.vy;
   }
};

funText.prototype.findTarget = function (e, delta) {
   //general updates
};

funText.prototype.updateTracker = function (e, delta) {
   if (e.enterTimer < 0) {
      e.enterTimer += 1;
      return;
   }

   if (e.tween) {
      if (e.moveTimer < 0) {
         e.moveTimer += 1;
      } else {
         const { x, y, complete } = e.tween.update(delta);
         e.baseX = x;
         e.baseY = y;
         if (complete) e.tween = null;
      }
   }

   if (e.link == null) {
      if (e.exitTimer < 0) {
         e.exitTimer += 1;
      } else {
         e.baseX = e.x;
         e.baseY = e.y;
         e.lockstep = true;
         this.flyaway(e, delta);
      }
   }

   if (e.link != null) e.opacity = Math.min(e.opacity + 0.006, 1);

   e.xp = e.x / this.playArea.width;
   e.yp = e.y / this.playArea.height;

   if (e.lockstep) {
      e.x = e.baseX;
      e.y = e.baseY;
   } else {
      e.x += (e.baseX - e.x) * 0.02;
      e.y += (e.baseY - e.y) * 0.02;

      if (getDistance(e, { x: e.baseX, y: e.baseY }) < 0.2) {
         e.lockstep = true;
      }
   }
};

funText.prototype.update = function (delta) {
   this.trackers.forEach((e, i) => {
      this.updateTracker(e, delta);

      e.element.style.left = e.x + "px";
      e.element.style.top = e.y + "px";
      e.element.style.color = e.lockstep ? "yellow" : "white";

      if (e.link == null) e.element.style.color = "red";
      e.element.style.opacity = Math.min(e.opacity, 1);
   });
};
export { funText, getMinimumCharsFromStrings };
